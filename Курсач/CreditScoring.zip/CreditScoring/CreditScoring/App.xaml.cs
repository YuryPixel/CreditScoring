using System.Windows;

namespace CreditScoring
{
    /// <summary>
    /// Класс приложения. Весь запуск описан в App.xaml (StartupUri),
    /// поэтому дополнительный код здесь не нужен.
    /// </summary>
    public partial class App : Application
    {
    }
}
