using CreditScoring.Models;

namespace CreditScoring.Scoring
{
    /// <summary>
    /// Абстрактный критерий скоринговой карты (абстракция).
    /// У каждого критерия есть название и метод, который начисляет баллы.
    /// Как именно начисляются баллы — решает каждый класс-наследник (полиморфизм).
    /// </summary>
    public abstract class Criterion
    {
        /// <summary>Название критерия, например «Возраст».</summary>
        public string Name { get; }

        /// <summary>Конструктор: задаёт название критерия.</summary>
        protected Criterion(string name)
        {
            Name = name;
        }

        /// <summary>Вернуть баллы, которые получает заявка по этому критерию.</summary>
        public abstract int GetPoints(CreditApplication application);
    }
}
