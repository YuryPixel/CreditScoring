using System;
using System.Collections.Generic;
using CreditScoring.Models;

namespace CreditScoring.Scoring
{
    /// <summary>
    /// Скоринговая оценка заявки по методу из подраздела 1.2.7:
    /// 1) платёж и ПДН; 2) баллы по 13 критериям; 3) вероятность дефолта;
    /// 4) стоп-факторы; 5) итоговое решение с учётом Кредитного регистра.
    /// </summary>
    public class ScoringService
    {
        // Базовый балл, к которому прибавляются баллы критериев.
        private const int BaseScore = 200;

        // Параметры перевода балла в вероятность дефолта (формулы 1.6, 1.7).
        // Factor = 50 / ln 2;  Offset = 600 − Factor · ln 50.
        private static readonly double Factor = 50 / Math.Log(2);
        private static readonly double Offset = 600 - Factor * Math.Log(50);

        // Бюджет прожиточного минимума (с 01.11.2026), руб.
        private const decimal SubsistenceMinimum = 535.70m;

        // Список критериев. Тип элементов — базовый класс Criterion,
        // а лежат в нём объекты разных классов-наследников (полиморфизм).
        private readonly List<Criterion> _criteria = new List<Criterion>
        {
            new AgeCriterion(), new MaritalCriterion(), new DependentsCriterion(),
            new EducationCriterion(), new EmploymentCriterion(), new ExperienceCriterion(),
            new IncomeCriterion(), new PdnCriterion(), new LoanToIncomeCriterion(),
            new RealEstateCriterion(), new SalaryClientCriterion(),
            new CreditClassCriterion(), new OverdueCriterion()
        };

        /// <summary>
        /// Главный метод: рассчитать скоринг и записать результаты в заявку.
        /// </summary>
        public void Calculate(CreditApplication a)
        {
            // Шаг 1. Платёж по новому кредиту и ПДН.
            a.MonthlyPayment = AnnuityPayment(a.Amount, a.Rate, a.TermMonths);
            a.Pdn = CalculatePdn(a);

            // Шаг 2. Баллы по каждому критерию.
            a.Details.Clear();
            int score = BaseScore;
            foreach (Criterion criterion in _criteria)
            {
                int points = criterion.GetPoints(a); // вызывается метод нужного наследника
                score += points;
                a.Details.Add(criterion.Name + ": " + (points > 0 ? "+" : "") + points);
            }
            a.Score = score;

            // Шаг 3. Вероятность дефолта, %.
            a.Pd = Math.Round(100.0 / (1.0 + Math.Exp((score - Offset) / Factor)), 2);

            // Шаг 4–5. Стоп-факторы и решение.
            a.StopFactors = CheckStopFactors(a);
            a.Decision = MakeDecision(a);
        }

        /// <summary>
        /// Аннуитетный платёж (формула 1.1): P = S·i / (1 − (1 + i)^(−n)), i = r / 12 / 100.
        /// </summary>
        public static decimal AnnuityPayment(decimal amount, decimal rate, int months)
        {
            if (amount <= 0 || months <= 0) return 0;
            if (rate == 0) return Math.Round(amount / months, 2);

            double i = (double)rate / 12 / 100;  // месячная ставка
            double p = (double)amount * i / (1 - Math.Pow(1 + i, -months));
            return Math.Round((decimal)p, 2);
        }

        /// <summary>ПДН (формула 1.2): (платежи по другим кредитам + новый платёж) / доход · 100 %.</summary>
        private static decimal CalculatePdn(CreditApplication a)
        {
            if (a.Client.Income <= 0) return 999; // дохода нет — нагрузка «бесконечная»
            return Math.Round((a.OtherPayments + a.MonthlyPayment) / a.Client.Income * 100, 2);
        }

        /// <summary>Проверить стоп-факторы (таблица 1.10). Возвращает список причин отказа.</summary>
        private static List<string> CheckStopFactors(CreditApplication a)
        {
            var list = new List<string>();
            Client c = a.Client;
            int age = c.GetAge(DateTime.Today);
            int ageAtEnd = c.GetAge(DateTime.Today.AddMonths(a.TermMonths));
            // Остаточный доход на одного члена семьи (формула 1.3).
            decimal residual = (c.Income - a.OtherPayments - a.MonthlyPayment) / (1 + c.Dependents);

            if (age < 21) list.Add("Возраст менее 21 года");
            if (ageAtEnd > 70) list.Add("Возраст на дату погашения более 70 лет");
            if (c.Income <= 0) list.Add("Нет подтверждённого дохода");
            if (c.HasCurrentOverdue || c.CreditClass == "F") list.Add("Есть текущая просроченная задолженность");
            if (a.Pdn > 40) list.Add("ПДН " + a.Pdn + " % — более 40 %");
            if (c.Income > 0 && residual < SubsistenceMinimum)
                list.Add("Остаточный доход на члена семьи меньше БПМ (" + SubsistenceMinimum + " руб.)");
            if (c.EmploymentType != Dictionaries.Pensioner && c.ExperienceMonths < 3)
                list.Add("Стаж на текущем месте менее 3 месяцев");
            return list;
        }

        /// <summary>
        /// Итоговое решение: категория риска по баллу (таблица 1.9),
        /// затем поправка по Кредитному регистру (матрица, таблица 1.11).
        /// </summary>
        private static string MakeDecision(CreditApplication a)
        {
            if (a.StopFactors.Count > 0) return Dictionaries.Reject;

            // Решение только по баллу.
            string decision;
            if (a.Score >= 560) decision = Dictionaries.Approve;      // низкий риск
            else if (a.Score >= 480) decision = Dictionaries.Rework;  // средний риск
            else decision = Dictionaries.Reject;                      // высокий риск

            // Слабая кредитная история (класс D или E) понижает решение на одну ступень.
            bool weakHistory = a.Client.CreditClass == "D" || a.Client.CreditClass == "E";
            if (weakHistory && decision == Dictionaries.Approve) return Dictionaries.Rework;
            if (weakHistory && decision == Dictionaries.Rework) return Dictionaries.Reject;
            return decision;
        }

        /// <summary>Категория риска по баллу — для отчёта.</summary>
        public static string GetRiskCategory(int score)
        {
            if (score >= 560) return "Низкий риск";
            if (score >= 480) return "Средний риск";
            return "Высокий риск";
        }
    }
}
