using System;
using CreditScoring.Models;

// В этом файле — 13 критериев скоринговой карты (таблица 1.8 пояснительной записки).
// Каждый критерий — отдельный класс, наследник Criterion.
// Каждый класс переопределяет метод GetPoints и возвращает баллы по своему правилу.
namespace CreditScoring.Scoring
{
    /// <summary>K01. Возраст клиента.</summary>
    public class AgeCriterion : Criterion
    {
        public AgeCriterion() : base("Возраст") { }

        public override int GetPoints(CreditApplication a)
        {
            int age = a.Client.GetAge(DateTime.Today);
            if (age < 25) return 10;
            if (age < 35) return 30;
            if (age < 50) return 45;
            if (age < 60) return 35;
            return 15;
        }
    }

    /// <summary>K02. Семейное положение.</summary>
    public class MaritalCriterion : Criterion
    {
        public MaritalCriterion() : base("Семейное положение") { }

        public override int GetPoints(CreditApplication a)
        {
            switch (a.Client.MaritalStatus)
            {
                case Dictionaries.Married: return 35;
                case Dictionaries.Widowed: return 20;
                case Dictionaries.Single: return 15;
                default: return 10; // разведён(а)
            }
        }
    }

    /// <summary>K03. Количество иждивенцев.</summary>
    public class DependentsCriterion : Criterion
    {
        public DependentsCriterion() : base("Количество иждивенцев") { }

        public override int GetPoints(CreditApplication a)
        {
            int d = a.Client.Dependents;
            if (d == 0) return 30;
            if (d == 1) return 25;
            if (d == 2) return 15;
            return 0; // 3 и более
        }
    }

    /// <summary>K04. Образование.</summary>
    public class EducationCriterion : Criterion
    {
        public EducationCriterion() : base("Образование") { }

        public override int GetPoints(CreditApplication a)
        {
            switch (a.Client.Education)
            {
                case Dictionaries.Postgraduate: return 35;
                case Dictionaries.Higher: return 30;
                case Dictionaries.Specialized: return 15;
                case Dictionaries.Vocational: return 10;
                default: return 5; // общее среднее
            }
        }
    }

    /// <summary>K05. Тип занятости.</summary>
    public class EmploymentCriterion : Criterion
    {
        public EmploymentCriterion() : base("Тип занятости") { }

        public override int GetPoints(CreditApplication a)
        {
            switch (a.Client.EmploymentType)
            {
                case Dictionaries.PublicSector: return 40;
                case Dictionaries.PrivateSector: return 30;
                case Dictionaries.Pensioner: return 25;
                default: return 15; // индивидуальный предприниматель
            }
        }
    }

    /// <summary>K06. Стаж на текущем месте работы, мес.</summary>
    public class ExperienceCriterion : Criterion
    {
        public ExperienceCriterion() : base("Стаж на текущем месте") { }

        public override int GetPoints(CreditApplication a)
        {
            int m = a.Client.ExperienceMonths;
            if (m < 6) return 0;
            if (m < 12) return 10;
            if (m < 36) return 25;
            if (m < 60) return 35;
            return 45;
        }
    }

    /// <summary>K07. Подтверждённый доход, руб. в месяц.</summary>
    public class IncomeCriterion : Criterion
    {
        public IncomeCriterion() : base("Подтверждённый доход") { }

        public override int GetPoints(CreditApplication a)
        {
            decimal income = a.Client.Income;
            if (income < 1000) return 0;
            if (income < 1500) return 10;
            if (income < 2500) return 25;
            if (income < 4000) return 40;
            return 50;
        }
    }

    /// <summary>K08. Показатель долговой нагрузки (ПДН), %.</summary>
    public class PdnCriterion : Criterion
    {
        public PdnCriterion() : base("Показатель долговой нагрузки") { }

        public override int GetPoints(CreditApplication a)
        {
            // ПДН уже рассчитан в ScoringService до вызова критериев.
            if (a.Pdn < 20) return 50;
            if (a.Pdn < 30) return 35;
            if (a.Pdn < 35) return 20;
            return 5;
        }
    }

    /// <summary>K09. Отношение суммы кредита к годовому доходу.</summary>
    public class LoanToIncomeCriterion : Criterion
    {
        public LoanToIncomeCriterion() : base("Кредит / годовой доход") { }

        public override int GetPoints(CreditApplication a)
        {
            if (a.Client.Income <= 0) return 0;
            decimal ratio = a.Amount / (a.Client.Income * 12);
            if (ratio < 0.5m) return 30;
            if (ratio < 1m) return 20;
            if (ratio < 2m) return 10;
            return 0;
        }
    }

    /// <summary>K10. Недвижимость в собственности.</summary>
    public class RealEstateCriterion : Criterion
    {
        public RealEstateCriterion() : base("Недвижимость в собственности") { }

        public override int GetPoints(CreditApplication a)
        {
            return a.Client.HasRealEstate ? 20 : 0;
        }
    }

    /// <summary>K11. Зарплатный (пенсионный) клиент банка.</summary>
    public class SalaryClientCriterion : Criterion
    {
        public SalaryClientCriterion() : base("Зарплатный клиент банка") { }

        public override int GetPoints(CreditApplication a)
        {
            return a.Client.IsSalaryClient ? 20 : 0;
        }
    }

    /// <summary>K12. Класс рейтинга Кредитного регистра.</summary>
    public class CreditClassCriterion : Criterion
    {
        public CreditClassCriterion() : base("Класс Кредитного регистра") { }

        public override int GetPoints(CreditApplication a)
        {
            switch (a.Client.CreditClass)
            {
                case "A": return 70;
                case "B": return 55;
                case "C": return 35;
                case "D": return 10;
                case "E": return -20;
                case "F": return -40;
                default: return 25; // нет кредитной истории
            }
        }
    }

    /// <summary>K13. Максимальная просрочка за 24 месяца, дней.</summary>
    public class OverdueCriterion : Criterion
    {
        public OverdueCriterion() : base("Максимальная просрочка") { }

        public override int GetPoints(CreditApplication a)
        {
            int days = a.Client.MaxOverdueDays;
            if (days == 0) return 30;
            if (days <= 7) return 20;
            if (days <= 30) return 5;
            if (days <= 90) return -20;
            return -40;
        }
    }
}
