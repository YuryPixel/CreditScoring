using System.Windows;

namespace CreditScoring.Views
{
    /// <summary>
    /// Код окна ввода заявки. Логики здесь нет — она в EditViewModel (паттерн MVVM).
    /// </summary>
    public partial class EditWindow : Window
    {
        public EditWindow()
        {
            InitializeComponent(); // создаёт элементы, описанные в EditWindow.xaml
        }
    }
}
