using System.Windows;

namespace CreditScoring.Views
{
    /// <summary>
    /// Код главного окна. По паттерну MVVM вся логика находится в MainViewModel,
    /// здесь только обработчик пункта меню «Выход».
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent(); // создаёт элементы, описанные в MainWindow.xaml
        }

        /// <summary>Пункт меню «Файл → Выход»: закрыть окно (и программу).</summary>
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
