using System.Windows;
using CreditScoring.ViewModels;
using CreditScoring.Views;
using Microsoft.Win32;

namespace CreditScoring.Services
{
    /// <summary>
    /// Все окна-диалоги программы собраны в одном классе:
    /// сообщения, вопросы «Да/Нет», выбор файла, окно заявки.
    /// Модели представления вызывают эти методы и сами не создают окна.
    /// </summary>
    public static class Dialogs
    {
        // Фильтры для стандартных окон выбора файла.
        public const string JsonFilter = "Журнал заявок (*.json)|*.json";
        public const string TxtFilter = "Текстовый файл (*.txt)|*.txt";

        /// <summary>Информационное сообщение.</summary>
        public static void Info(string text)
        {
            MessageBox.Show(text, "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        /// <summary>Сообщение об ошибке.</summary>
        public static void Error(string text)
        {
            MessageBox.Show(text, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        /// <summary>Вопрос с ответом «Да / Нет». Возвращает true, если нажато «Да».</summary>
        public static bool Ask(string text)
        {
            return MessageBox.Show(text, "Подтверждение", MessageBoxButton.YesNo,
                       MessageBoxImage.Question) == MessageBoxResult.Yes;
        }

        /// <summary>Окно «Открыть файл». Возвращает путь или null, если пользователь отменил.</summary>
        public static string? OpenFile(string filter)
        {
            var dialog = new OpenFileDialog { Filter = filter };
            return dialog.ShowDialog() == true ? dialog.FileName : null;
        }

        /// <summary>Окно «Сохранить файл». Возвращает путь или null.</summary>
        public static string? SaveFile(string filter, string defaultName)
        {
            var dialog = new SaveFileDialog { Filter = filter, FileName = defaultName };
            return dialog.ShowDialog() == true ? dialog.FileName : null;
        }

        /// <summary>
        /// Открыть окно ввода заявки. Возвращает true, если пользователь нажал «Сохранить».
        /// </summary>
        public static bool EditApplication(EditViewModel viewModel)
        {
            var window = new EditWindow();
            window.DataContext = viewModel;              // связываем окно с моделью представления
            window.Owner = Application.Current.MainWindow;
            // Модель представления закроет окно через этот делегат.
            viewModel.CloseAction = result => window.DialogResult = result;
            return window.ShowDialog() == true;
        }
    }
}
