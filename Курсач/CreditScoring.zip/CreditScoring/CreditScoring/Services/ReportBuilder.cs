using System.Collections.Generic;
using System.Text;
using CreditScoring.Models;
using CreditScoring.Scoring;

namespace CreditScoring.Services
{
    /// <summary>
    /// Формирование текста отчётов: заключение по одной заявке и список заявок.
    /// Текст показывается в окне и по запросу сохраняется в файл TXT.
    /// </summary>
    public static class ReportBuilder
    {
        /// <summary>Заключение по одной заявке.</summary>
        public static string BuildConclusion(CreditApplication a)
        {
            // StringBuilder удобен, когда строка собирается из многих частей.
            var sb = new StringBuilder();
            sb.AppendLine("ЗАКЛЮЧЕНИЕ ПО ПРЕДВАРИТЕЛЬНОЙ ОЦЕНКЕ КРЕДИТОСПОСОБНОСТИ");
            sb.AppendLine("Заявка № " + a.Number + " от " + a.CreatedAt.ToString("dd.MM.yyyy HH:mm"));
            sb.AppendLine("Клиент: " + a.Client.GetInfo());
            sb.AppendLine("Кредит: " + a.Amount.ToString("N2") + " руб. на " + a.TermMonths +
                          " мес. под " + a.Rate + " % годовых");
            sb.AppendLine();
            sb.AppendLine("Подтверждённый доход: " + a.Client.Income.ToString("N2") + " руб./мес.");
            sb.AppendLine("Платежи по другим кредитам: " + a.OtherPayments.ToString("N2") + " руб./мес.");
            sb.AppendLine("Платёж по новому кредиту: " + a.MonthlyPayment.ToString("N2") + " руб./мес.");
            sb.AppendLine("ПДН: " + a.Pdn + " %");
            sb.AppendLine();
            sb.AppendLine("Баллы по критериям (базовый балл 200):");
            foreach (string line in a.Details)
            {
                sb.AppendLine("  " + line);
            }
            sb.AppendLine();
            sb.AppendLine("Итоговый балл: " + a.Score + " (" + ScoringService.GetRiskCategory(a.Score) + ")");
            sb.AppendLine("Вероятность дефолта: " + a.Pd + " %");
            foreach (string stop in a.StopFactors)
            {
                sb.AppendLine("Стоп-фактор: " + stop);
            }
            sb.AppendLine("ПРЕДВАРИТЕЛЬНОЕ РЕШЕНИЕ: " + a.Decision.ToUpper());
            return sb.ToString();
        }

        /// <summary>Список заявок в виде таблицы (например, результат поиска).</summary>
        public static string BuildList(IEnumerable<CreditApplication> applications)
        {
            var sb = new StringBuilder();
            sb.AppendLine("ЖУРНАЛ ЗАЯВОК");
            sb.AppendLine("№    Дата        Клиент                          Сумма       Балл  Решение");
            foreach (CreditApplication a in applications)
            {
                // {0,-4} — выравнивание по левому краю в поле шириной 4 символа и т. д.
                sb.AppendLine(string.Format("{0,-4} {1,-11:dd.MM.yyyy} {2,-30} {3,10:N2} {4,5}  {5}",
                    a.Number, a.CreatedAt, a.ClientName, a.Amount, a.Score, a.Decision));
            }
            return sb.ToString();
        }
    }
}
