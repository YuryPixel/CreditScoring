using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace CreditScoring.ViewModels
{
    /// <summary>
    /// Базовый класс для всех моделей представления (паттерн MVVM).
    /// Реализует интерфейс INotifyPropertyChanged: когда свойство меняется,
    /// окно получает уведомление и само обновляет текст на экране.
    /// </summary>
    public abstract class BaseViewModel : INotifyPropertyChanged
    {
        /// <summary>Событие «свойство изменилось» — на него подписывается WPF.</summary>
        public event PropertyChangedEventHandler? PropertyChanged;

        /// <summary>
        /// Сообщить окну, что свойство изменилось.
        /// [CallerMemberName] подставляет имя свойства автоматически.
        /// </summary>
        protected void OnPropertyChanged([CallerMemberName] string? name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
