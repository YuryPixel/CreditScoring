using System;
using System.Globalization;
using CreditScoring.Models;
using CreditScoring.Scoring;
using CreditScoring.Services;

namespace CreditScoring.ViewModels
{
    /// <summary>
    /// Модель представления окна ввода заявки (EditWindow).
    /// Хранит значения полей формы, проверяет их, рассчитывает скоринг
    /// и собирает объект CreditApplication.
    /// </summary>
    public class EditViewModel : BaseViewModel
    {
        private readonly ScoringService _scoring = new ScoringService();
        private string _resultText = "Заполните поля и нажмите «Рассчитать».";

        // Номер и дата редактируемой заявки (для новой заявки — 0 и текущая дата).
        private readonly int _number;
        private readonly DateTime _createdAt;

        /// <summary>
        /// Конструктор. Если передана существующая заявка — поля формы заполняются её данными
        /// (режим редактирования), иначе форма пустая (новая заявка).
        /// </summary>
        public EditViewModel(CreditApplication? existing)
        {
            CalculateCommand = new RelayCommand(Calculate);
            SaveCommand = new RelayCommand(Save);
            CancelCommand = new RelayCommand(() => CloseAction?.Invoke(false));
            _createdAt = DateTime.Now;
            if (existing != null)
            {
                _number = existing.Number;
                _createdAt = existing.CreatedAt;
                LoadFrom(existing);
            }
        }

        // ----- Списки для выпадающих списков (ComboBox) -----
        public string[] MaritalStatuses => Dictionaries.MaritalStatuses;
        public string[] Educations => Dictionaries.Educations;
        public string[] EmploymentTypes => Dictionaries.EmploymentTypes;
        public string[] CreditClasses => Dictionaries.CreditClasses;

        // ----- Поля формы. Числа хранятся строками, чтобы проверить ввод самим. -----
        public string LastName { get; set; } = "";
        public string FirstName { get; set; } = "";
        public string MiddleName { get; set; } = "";
        public DateTime? BirthDate { get; set; }
        public string Passport { get; set; } = "";
        public string MaritalStatus { get; set; } = Dictionaries.Married;
        public string Dependents { get; set; } = "0";
        public string Education { get; set; } = Dictionaries.Higher;
        public string EmploymentType { get; set; } = Dictionaries.PrivateSector;
        public string Experience { get; set; } = "";
        public string Income { get; set; } = "";
        public bool HasRealEstate { get; set; }
        public bool IsSalaryClient { get; set; }
        public string CreditClass { get; set; } = Dictionaries.NoHistory;
        public string MaxOverdueDays { get; set; } = "0";
        public bool HasCurrentOverdue { get; set; }
        public string OtherPayments { get; set; } = "0";
        public string Amount { get; set; } = "";
        public string Term { get; set; } = "36";
        public string Rate { get; set; } = "17,65";

        /// <summary>Текст результата расчёта (показывается справа в окне).</summary>
        public string ResultText
        {
            get { return _resultText; }
            set { _resultText = value; OnPropertyChanged(); }
        }

        // ----- Команды кнопок -----
        public RelayCommand CalculateCommand { get; }
        public RelayCommand SaveCommand { get; }
        public RelayCommand CancelCommand { get; }

        /// <summary>Действие закрытия окна (задаётся в Dialogs.EditApplication).</summary>
        public Action<bool>? CloseAction { get; set; }

        /// <summary>Готовая заявка — заполняется при нажатии «Сохранить».</summary>
        public CreditApplication? Result { get; private set; }

        /// <summary>Кнопка «Рассчитать»: проверить данные и показать результат скоринга.</summary>
        private void Calculate()
        {
            CreditApplication? application = TryBuild();
            if (application != null)
            {
                ResultText = ReportBuilder.BuildConclusion(application);
            }
        }

        /// <summary>Кнопка «Сохранить»: проверить, рассчитать и закрыть окно с результатом true.</summary>
        private void Save()
        {
            CreditApplication? application = TryBuild();
            if (application != null)
            {
                Result = application;
                CloseAction?.Invoke(true);
            }
        }

        /// <summary>
        /// Проверить все поля и собрать заявку. Если есть ошибки — показать их и вернуть null.
        /// </summary>
        private CreditApplication? TryBuild()
        {
            string errors = Validate();
            if (errors != "")
            {
                Dialogs.Error("Исправьте ошибки ввода:\n" + errors);
                return null;
            }
            CreditApplication a = Build();
            _scoring.Calculate(a); // сразу считаем скоринг
            return a;
        }

        /// <summary>
        /// Проверка введённых данных. Возвращает текст ошибок (пустая строка — ошибок нет).
        /// </summary>
        private string Validate()
        {
            string e = "";
            if (LastName.Trim() == "") e += "– не указана фамилия;\n";
            if (FirstName.Trim() == "") e += "– не указано имя;\n";
            if (BirthDate == null || BirthDate > DateTime.Today) e += "– неверная дата рождения;\n";
            if (!System.Text.RegularExpressions.Regex.IsMatch(Passport.Trim().ToUpper(), "^[A-Z]{2}[0-9]{7}$"))
                e += "– паспорт: две латинские буквы и 7 цифр (MP1234567);\n";
            if (!IsNumber(Dependents, 0, 10)) e += "– иждивенцы: целое число от 0 до 10;\n";
            if (!IsNumber(Experience, 0, 720)) e += "– стаж: число месяцев от 0 до 720;\n";
            if (!IsNumber(Income, 0, 1000000)) e += "– доход: число от 0 до 1 000 000;\n";
            if (!IsNumber(MaxOverdueDays, 0, 3650)) e += "– просрочка: число дней от 0 до 3650;\n";
            if (!IsNumber(OtherPayments, 0, 1000000)) e += "– платежи по другим кредитам: число от 0;\n";
            if (!IsNumber(Amount, 100, 50000)) e += "– сумма кредита: от 100 до 50 000 руб.;\n";
            if (!IsNumber(Term, 3, 60)) e += "– срок: от 3 до 60 месяцев;\n";
            if (!IsNumber(Rate, 0, 50)) e += "– ставка: от 0 до 50 %;\n";
            return e;
        }

        /// <summary>Собрать объект заявки из полей формы (вызывается после успешной проверки).</summary>
        private CreditApplication Build()
        {
            var client = new Client
            {
                LastName = LastName,
                FirstName = FirstName.Trim(),
                MiddleName = MiddleName.Trim(),
                BirthDate = BirthDate!.Value,
                Passport = Passport.Trim().ToUpper(),
                MaritalStatus = MaritalStatus,
                Dependents = (int)ToNumber(Dependents),
                Education = Education,
                EmploymentType = EmploymentType,
                ExperienceMonths = (int)ToNumber(Experience),
                Income = ToNumber(Income),
                HasRealEstate = HasRealEstate,
                IsSalaryClient = IsSalaryClient,
                CreditClass = CreditClass,
                MaxOverdueDays = (int)ToNumber(MaxOverdueDays),
                HasCurrentOverdue = HasCurrentOverdue
            };
            return new CreditApplication
            {
                Number = _number,
                CreatedAt = _createdAt,
                Client = client,
                Amount = ToNumber(Amount),
                TermMonths = (int)ToNumber(Term),
                Rate = ToNumber(Rate),
                OtherPayments = ToNumber(OtherPayments)
            };
        }

        /// <summary>Заполнить поля формы данными существующей заявки.</summary>
        private void LoadFrom(CreditApplication a)
        {
            Client c = a.Client;
            LastName = c.LastName;
            FirstName = c.FirstName;
            MiddleName = c.MiddleName;
            BirthDate = c.BirthDate;
            Passport = c.Passport;
            MaritalStatus = c.MaritalStatus;
            Dependents = c.Dependents.ToString();
            Education = c.Education;
            EmploymentType = c.EmploymentType;
            Experience = c.ExperienceMonths.ToString();
            Income = c.Income.ToString();
            HasRealEstate = c.HasRealEstate;
            IsSalaryClient = c.IsSalaryClient;
            CreditClass = c.CreditClass;
            MaxOverdueDays = c.MaxOverdueDays.ToString();
            HasCurrentOverdue = c.HasCurrentOverdue;
            OtherPayments = a.OtherPayments.ToString();
            Amount = a.Amount.ToString();
            Term = a.TermMonths.ToString();
            Rate = a.Rate.ToString();
            ResultText = ReportBuilder.BuildConclusion(a);
        }

        /// <summary>Проверить, что строка — число в диапазоне [min; max]. Разделитель — запятая или точка.</summary>
        private static bool IsNumber(string text, decimal min, decimal max)
        {
            string s = (text ?? "").Trim().Replace(',', '.');
            return decimal.TryParse(s, NumberStyles.Number, CultureInfo.InvariantCulture, out decimal v)
                   && v >= min && v <= max;
        }

        /// <summary>Преобразовать строку в число (строка уже проверена методом IsNumber).</summary>
        private static decimal ToNumber(string text)
        {
            return decimal.Parse(text.Trim().Replace(',', '.'), CultureInfo.InvariantCulture);
        }
    }
}
