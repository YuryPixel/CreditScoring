using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using CreditScoring.Data;
using CreditScoring.Models;
using CreditScoring.Services;

namespace CreditScoring.ViewModels
{
    /// <summary>
    /// Модель представления главного окна.
    /// Хранит журнал заявок, выполняет команды меню: работа с файлом,
    /// добавление / изменение / удаление заявок, поиск, сортировка, отчёты.
    /// </summary>
    public class MainViewModel : BaseViewModel
    {
        private readonly FileService _files = new FileService();

        // Все заявки журнала (загружаются из файла один раз при открытии).
        private List<CreditApplication> _all = new List<CreditApplication>();

        // Путь к открытому файлу (null — файл не открыт).
        private string? _filePath;

        private CreditApplication? _selected;
        private string _status = "Создайте или откройте файл журнала (меню «Файл»).";

        /// <summary>Конструктор: создаём команды для меню и кнопок.</summary>
        public MainViewModel()
        {
            NewFileCommand = new RelayCommand(NewFile);
            OpenFileCommand = new RelayCommand(OpenFile);
            SaveFileCommand = new RelayCommand(SaveFile);
            DeleteFileCommand = new RelayCommand(DeleteFile);
            AddCommand = new RelayCommand(Add);
            EditCommand = new RelayCommand(Edit);
            DeleteCommand = new RelayCommand(Delete);
            SearchCommand = new RelayCommand(Refresh);
            ResetCommand = new RelayCommand(ResetSearch);
            SaveReportCommand = new RelayCommand(SaveReport);
            SaveListCommand = new RelayCommand(SaveList);
            AboutCommand = new RelayCommand(() => Dialogs.Info(
                "Система скоринга для предварительной оценки кредитоспособности физических лиц.\n" +
                "Курсовой проект по дисциплине «ООПиП»."));
        }

        // ===== Данные для окна =====

        /// <summary>Заявки, показанные в таблице (после поиска и сортировки).</summary>
        public ObservableCollection<CreditApplication> Applications { get; } =
            new ObservableCollection<CreditApplication>();

        /// <summary>Выбранная в таблице заявка. При выборе обновляется текст заключения.</summary>
        public CreditApplication? Selected
        {
            get { return _selected; }
            set
            {
                _selected = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(SelectedReport));
            }
        }

        /// <summary>Текст заключения по выбранной заявке (правая панель окна).</summary>
        public string SelectedReport
        {
            get { return _selected == null ? "Выберите заявку в таблице." : ReportBuilder.BuildConclusion(_selected); }
        }

        /// <summary>Строка состояния внизу окна.</summary>
        public string Status
        {
            get { return _status; }
            set { _status = value; OnPropertyChanged(); }
        }

        // ===== Параметры поиска и сортировки =====

        /// <summary>Поиск: часть ФИО.</summary>
        public string SearchName { get; set; } = "";

        /// <summary>Поиск: решение («Все» — без отбора).</summary>
        public string SearchDecision { get; set; } = "Все";

        /// <summary>Поиск: минимальный балл (пусто — без отбора).</summary>
        public string SearchMinScore { get; set; } = "";

        /// <summary>Список решений для ComboBox поиска.</summary>
        public string[] DecisionList { get; } = { "Все", Dictionaries.Approve, Dictionaries.Rework, Dictionaries.Reject };

        /// <summary>Варианты сортировки.</summary>
        public string[] SortList { get; } = { "По номеру", "По ФИО", "По баллу", "По сумме" };

        /// <summary>Выбранный вариант сортировки.</summary>
        public string SortBy { get; set; } = "По номеру";

        /// <summary>Сортировать по убыванию.</summary>
        public bool SortDescending { get; set; }

        // ===== Команды (привязаны к меню и кнопкам в MainWindow.xaml) =====
        public RelayCommand NewFileCommand { get; }
        public RelayCommand OpenFileCommand { get; }
        public RelayCommand SaveFileCommand { get; }
        public RelayCommand DeleteFileCommand { get; }
        public RelayCommand AddCommand { get; }
        public RelayCommand EditCommand { get; }
        public RelayCommand DeleteCommand { get; }
        public RelayCommand SearchCommand { get; }
        public RelayCommand ResetCommand { get; }
        public RelayCommand SaveReportCommand { get; }
        public RelayCommand SaveListCommand { get; }
        public RelayCommand AboutCommand { get; }

        // ===== Работа с файлом =====

        /// <summary>Создать новый пустой файл журнала.</summary>
        private void NewFile()
        {
            string? path = Dialogs.SaveFile(Dialogs.JsonFilter, "journal.json");
            if (path == null) return; // пользователь нажал «Отмена»
            _all = new List<CreditApplication>();
            _filePath = path;
            SaveFile();
            Refresh();
        }

        /// <summary>Открыть существующий файл журнала.</summary>
        private void OpenFile()
        {
            string? path = Dialogs.OpenFile(Dialogs.JsonFilter);
            if (path == null) return;
            try
            {
                _all = _files.Load(path);
                _filePath = path;
                Refresh();
                Status = "Открыт файл " + Path.GetFileName(path) + ", заявок: " + _all.Count;
            }
            catch (Exception ex)
            {
                // Файл повреждён или имеет неверный формат — программа не падает.
                Dialogs.Error("Не удалось открыть файл:\n" + ex.Message);
            }
        }

        /// <summary>Сохранить журнал в открытый файл.</summary>
        private void SaveFile()
        {
            if (!CheckFileOpen()) return;
            try
            {
                _files.Save(_filePath!, _all);
                Status = "Журнал сохранён: " + Path.GetFileName(_filePath);
            }
            catch (Exception ex)
            {
                Dialogs.Error("Не удалось сохранить файл:\n" + ex.Message);
            }
        }

        /// <summary>Удалить файл журнала (с подтверждением).</summary>
        private void DeleteFile()
        {
            if (!CheckFileOpen()) return;
            if (!Dialogs.Ask("Вы действительно хотите удалить файл " + Path.GetFileName(_filePath) + "?"))
                return;
            try
            {
                _files.Delete(_filePath!);
                _all.Clear();
                _filePath = null;
                Refresh();
                Status = "Файл удалён.";
            }
            catch (Exception ex)
            {
                Dialogs.Error("Не удалось удалить файл:\n" + ex.Message);
            }
        }

        // ===== Добавление, изменение, удаление заявок =====

        /// <summary>Добавить новую заявку: открыть окно ввода, затем добавить в журнал.</summary>
        private void Add()
        {
            if (!CheckFileOpen()) return;
            var editor = new EditViewModel(null);
            if (!Dialogs.EditApplication(editor)) return;   // нажата «Отмена»

            CreditApplication a = editor.Result!;
            // Новый номер = максимальный номер + 1.
            a.Number = _all.Count == 0 ? 1 : _all.Max(x => x.Number) + 1;
            _all.Add(a);
            SaveFile();                                      // сразу сохраняем в файл
            Refresh();
            Selected = a;
            Status = "Добавлена заявка № " + a.Number + ": " + a.Decision;
        }

        /// <summary>Изменить выбранную заявку.</summary>
        private void Edit()
        {
            if (!CheckSelected()) return;
            var editor = new EditViewModel(Selected);
            if (!Dialogs.EditApplication(editor)) return;

            // Заменяем старую заявку новой на том же месте в списке.
            int index = _all.IndexOf(Selected!);
            _all[index] = editor.Result!;
            SaveFile();
            Refresh();
            Selected = editor.Result;
            Status = "Заявка № " + editor.Result!.Number + " изменена.";
        }

        /// <summary>Удалить выбранную заявку (с подтверждением).</summary>
        private void Delete()
        {
            if (!CheckSelected()) return;
            if (!Dialogs.Ask("Вы действительно хотите удалить заявку № " + Selected!.Number + "?")) return;
            _all.Remove(Selected);
            SaveFile();
            Refresh();
            Status = "Заявка удалена.";
        }

        // ===== Поиск и сортировка =====

        /// <summary>
        /// Обновить таблицу: отобрать заявки по условиям поиска и отсортировать.
        /// Используется LINQ — методы Where и OrderBy.
        /// </summary>
        private void Refresh()
        {
            IEnumerable<CreditApplication> result = _all;

            // Поиск по части ФИО (без учёта регистра).
            if (SearchName.Trim() != "")
                result = result.Where(a => a.ClientName.ToLower().Contains(SearchName.Trim().ToLower()));

            // Поиск по решению.
            if (SearchDecision != "Все")
                result = result.Where(a => a.Decision == SearchDecision);

            // Поиск по минимальному баллу.
            if (SearchMinScore.Trim() != "")
            {
                if (int.TryParse(SearchMinScore, out int minScore))
                    result = result.Where(a => a.Score >= minScore);
                else
                    Dialogs.Error("Минимальный балл должен быть целым числом.");
            }

            // Сортировка по выбранному полю.
            switch (SortBy)
            {
                case "По ФИО": result = result.OrderBy(a => a.ClientName); break;
                case "По баллу": result = result.OrderBy(a => a.Score); break;
                case "По сумме": result = result.OrderBy(a => a.Amount); break;
                default: result = result.OrderBy(a => a.Number); break;
            }
            if (SortDescending) result = result.Reverse();

            // Переносим результат в коллекцию, которую видит таблица.
            Applications.Clear();
            foreach (CreditApplication a in result)
                Applications.Add(a);
            Status = "Показано заявок: " + Applications.Count + " из " + _all.Count;
        }

        /// <summary>Сбросить параметры поиска и показать все заявки.</summary>
        private void ResetSearch()
        {
            SearchName = "";
            SearchDecision = "Все";
            SearchMinScore = "";
            // Сообщаем окну, что поля поиска очищены.
            OnPropertyChanged(nameof(SearchName));
            OnPropertyChanged(nameof(SearchDecision));
            OnPropertyChanged(nameof(SearchMinScore));
            Refresh();
        }

        // ===== Отчёты в TXT =====

        /// <summary>Сохранить заключение по выбранной заявке в текстовый файл.</summary>
        private void SaveReport()
        {
            if (!CheckSelected()) return;
            string? path = Dialogs.SaveFile(Dialogs.TxtFilter, "Заключение_" + Selected!.Number + ".txt");
            if (path == null) return;
            _files.SaveText(path, ReportBuilder.BuildConclusion(Selected));
            Dialogs.Info("Заключение сохранено в файл:\n" + path);
        }

        /// <summary>Сохранить список заявок из таблицы (результат поиска) в текстовый файл.</summary>
        private void SaveList()
        {
            if (!CheckFileOpen()) return;
            string? path = Dialogs.SaveFile(Dialogs.TxtFilter, "Журнал.txt");
            if (path == null) return;
            _files.SaveText(path, ReportBuilder.BuildList(Applications));
            Dialogs.Info("Список сохранён в файл:\n" + path);
        }

        // ===== Вспомогательные проверки =====

        /// <summary>Проверить, что файл журнала открыт; иначе показать подсказку.</summary>
        private bool CheckFileOpen()
        {
            if (_filePath != null) return true;
            Dialogs.Info("Сначала создайте или откройте файл журнала (меню «Файл»).");
            return false;
        }

        /// <summary>Проверить, что в таблице выбрана заявка.</summary>
        private bool CheckSelected()
        {
            if (Selected != null) return true;
            Dialogs.Info("Выберите заявку в таблице.");
            return false;
        }
    }
}
