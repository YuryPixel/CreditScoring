using System;
using System.Windows.Input;

namespace CreditScoring.ViewModels
{
    /// <summary>
    /// Команда для кнопок и пунктов меню (паттерн «Команда»).
    /// В XAML пишем Command="{Binding SaveCommand}", а при нажатии
    /// вызывается метод, переданный в конструктор.
    /// </summary>
    public class RelayCommand : ICommand
    {
        // Метод, который выполнится при нажатии кнопки.
        private readonly Action _execute;

        public RelayCommand(Action execute)
        {
            _execute = execute;
        }

        // Событие требуется интерфейсом ICommand; команда всегда доступна, поэтому оно не вызывается.
        public event EventHandler? CanExecuteChanged { add { } remove { } }

        /// <summary>Можно ли выполнить команду — у нас всегда можно.</summary>
        public bool CanExecute(object? parameter)
        {
            return true;
        }

        /// <summary>Выполнить команду.</summary>
        public void Execute(object? parameter)
        {
            _execute();
        }
    }
}
