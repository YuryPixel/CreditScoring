using System;

namespace CreditScoring.Models
{
    /// <summary>
    /// Клиент банка — заявитель на кредит.
    /// Наследуется от Person (наследование) и добавляет данные, нужные для скоринга.
    /// </summary>
    public class Client : Person
    {
        // Закрытое поле количества иждивенцев: значение проверяется в свойстве Dependents.
        private int _dependents;

        /// <summary>Серия и номер паспорта, например MP1234567.</summary>
        public string Passport { get; set; } = "";

        /// <summary>Семейное положение (значение из Dictionaries.MaritalStatuses).</summary>
        public string MaritalStatus { get; set; } = Dictionaries.Married;

        /// <summary>Количество иждивенцев (от 0 до 10).</summary>
        public int Dependents
        {
            get { return _dependents; }
            set
            {
                // Защита от неправильного значения (инкапсуляция).
                if (value < 0 || value > 10)
                {
                    throw new ArgumentException("Количество иждивенцев должно быть от 0 до 10.");
                }
                _dependents = value;
            }
        }

        /// <summary>Образование (значение из Dictionaries.Educations).</summary>
        public string Education { get; set; } = Dictionaries.Higher;

        /// <summary>Тип занятости (значение из Dictionaries.EmploymentTypes).</summary>
        public string EmploymentType { get; set; } = Dictionaries.PrivateSector;

        /// <summary>Стаж на текущем месте работы, месяцев.</summary>
        public int ExperienceMonths { get; set; }

        /// <summary>Подтверждённый справкой доход в месяц, руб. Устные сведения не учитываются.</summary>
        public decimal Income { get; set; }

        /// <summary>Есть недвижимость в собственности.</summary>
        public bool HasRealEstate { get; set; }

        /// <summary>Получает зарплату (пенсию) на счёт в нашем банке.</summary>
        public bool IsSalaryClient { get; set; }

        /// <summary>Класс рейтинга Кредитного регистра (значение из Dictionaries.CreditClasses).</summary>
        public string CreditClass { get; set; } = Dictionaries.NoHistory;

        /// <summary>Максимальная просрочка за последние 24 месяца, дней.</summary>
        public int MaxOverdueDays { get; set; }

        /// <summary>Есть непогашенная просрочка на сегодняшний день.</summary>
        public bool HasCurrentOverdue { get; set; }

        /// <summary>
        /// Переопределение абстрактного метода базового класса (полиморфизм):
        /// краткие сведения о клиенте для заключения.
        /// </summary>
        public override string GetInfo()
        {
            return FullName + ", " + BirthDate.ToString("dd.MM.yyyy") + " г. р., паспорт " + Passport;
        }
    }
}
