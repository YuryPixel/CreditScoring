namespace CreditScoring.Models
{
    /// <summary>
    /// Справочники — списки допустимых значений для выпадающих списков (ComboBox).
    /// Эти же строки используются в критериях скоринга, поэтому они хранятся в одном месте.
    /// </summary>
    public static class Dictionaries
    {
        // Семейное положение
        public const string Single = "Холост / не замужем";
        public const string Married = "Женат / замужем";
        public const string Divorced = "Разведён(а)";
        public const string Widowed = "Вдовец / вдова";

        public static readonly string[] MaritalStatuses = { Single, Married, Divorced, Widowed };

        // Образование
        public const string Secondary = "Общее среднее";
        public const string Vocational = "Профессионально-техническое";
        public const string Specialized = "Среднее специальное";
        public const string Higher = "Высшее";
        public const string Postgraduate = "Два высших / учёная степень";

        public static readonly string[] Educations = { Secondary, Vocational, Specialized, Higher, Postgraduate };

        // Тип занятости
        public const string PublicSector = "Работник бюджетной организации";
        public const string PrivateSector = "Работник коммерческой организации";
        public const string Entrepreneur = "Индивидуальный предприниматель";
        public const string Pensioner = "Пенсионер";

        public static readonly string[] EmploymentTypes = { PublicSector, PrivateSector, Entrepreneur, Pensioner };

        // Класс рейтинга Кредитного регистра (буква класса: A1–A3 → «A» и т. д.)
        public const string NoHistory = "Нет истории";

        public static readonly string[] CreditClasses = { NoHistory, "A", "B", "C", "D", "E", "F" };

        // Возможные решения по заявке
        public const string Approve = "Одобрить";
        public const string Rework = "Доработка";
        public const string Reject = "Отказать";

        public static readonly string[] Decisions = { Approve, Rework, Reject };
    }
}
