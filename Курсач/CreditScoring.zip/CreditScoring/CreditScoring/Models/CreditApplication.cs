using System;
using System.Collections.Generic;

namespace CreditScoring.Models
{
    /// <summary>
    /// Кредитная заявка: клиент, параметры кредита и результат скоринга.
    /// Именно такие объекты хранятся в файле журнала.
    /// </summary>
    public class CreditApplication
    {
        // Закрытое поле суммы кредита: проверка в свойстве Amount.
        private decimal _amount;

        /// <summary>Номер заявки в журнале.</summary>
        public int Number { get; set; }

        /// <summary>Дата и время создания заявки.</summary>
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        /// <summary>Заявитель.</summary>
        public Client Client { get; set; } = new Client();

        /// <summary>Сумма кредита, руб. Отрицательное значение недопустимо.</summary>
        public decimal Amount
        {
            get { return _amount; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Сумма кредита не может быть отрицательной.");
                }
                _amount = value;
            }
        }

        /// <summary>Срок кредита, месяцев.</summary>
        public int TermMonths { get; set; }

        /// <summary>Годовая процентная ставка, %.</summary>
        public decimal Rate { get; set; }

        /// <summary>Сумма ежемесячных платежей по другим (уже имеющимся) кредитам, руб.</summary>
        public decimal OtherPayments { get; set; }

        // ----- Результаты скоринга (заполняет ScoringService) -----

        /// <summary>Ежемесячный платёж по новому кредиту, руб.</summary>
        public decimal MonthlyPayment { get; set; }

        /// <summary>Показатель долговой нагрузки (ПДН), %.</summary>
        public decimal Pdn { get; set; }

        /// <summary>Скоринговый балл.</summary>
        public int Score { get; set; }

        /// <summary>Вероятность дефолта, %.</summary>
        public double Pd { get; set; }

        /// <summary>Предварительное решение: «Одобрить», «Доработка» или «Отказать».</summary>
        public string Decision { get; set; } = "";

        /// <summary>Расшифровка баллов по критериям (строки вида «Возраст: +45»).</summary>
        public List<string> Details { get; set; } = new List<string>();

        /// <summary>Сработавшие стоп-факторы (причины обязательного отказа).</summary>
        public List<string> StopFactors { get; set; } = new List<string>();

        /// <summary>ФИО клиента — для отображения в таблице.</summary>
        public string ClientName
        {
            get { return Client.FullName; }
        }
    }
}
