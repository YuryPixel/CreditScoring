using System;

namespace CreditScoring.Models
{
    /// <summary>
    /// Абстрактный класс «Физическое лицо».
    /// Содержит общие для всех людей данные: ФИО и дату рождения.
    /// Объект этого класса создать нельзя (abstract) — только объект наследника (Client).
    /// </summary>
    public abstract class Person
    {
        // Закрытое поле (инкапсуляция): к нему обращаются только через свойство LastName.
        private string _lastName = "";

        /// <summary>Фамилия. При записи лишние пробелы по краям удаляются.</summary>
        public string LastName
        {
            get { return _lastName; }
            set { _lastName = (value ?? "").Trim(); }
        }

        /// <summary>Имя.</summary>
        public string FirstName { get; set; } = "";

        /// <summary>Отчество (может быть пустым).</summary>
        public string MiddleName { get; set; } = "";

        /// <summary>Дата рождения.</summary>
        public DateTime BirthDate { get; set; }

        /// <summary>Полное имя «Фамилия Имя Отчество» (только чтение).</summary>
        public string FullName
        {
            get { return (LastName + " " + FirstName + " " + MiddleName).Trim(); }
        }

        /// <summary>
        /// Возраст — количество полных лет на указанную дату.
        /// </summary>
        public int GetAge(DateTime onDate)
        {
            int age = onDate.Year - BirthDate.Year;
            // Если день рождения в этом году ещё не наступил — вычитаем один год.
            if (BirthDate.Date > onDate.Date.AddYears(-age))
            {
                age--;
            }
            return age;
        }

        /// <summary>
        /// Абстрактный метод: краткие сведения о человеке для отчёта.
        /// Каждый наследник обязан его переопределить (полиморфизм).
        /// </summary>
        public abstract string GetInfo();
    }
}
