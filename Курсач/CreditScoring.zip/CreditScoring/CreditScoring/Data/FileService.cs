using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Unicode;
using CreditScoring.Models;

namespace CreditScoring.Data
{
    /// <summary>
    /// Работа с файлами: чтение и запись журнала заявок (JSON),
    /// удаление файла, сохранение текстового отчёта (TXT).
    /// </summary>
    public class FileService
    {
        // Настройки JSON: отступы для читаемости и русские буквы без кодирования \uXXXX.
        private readonly JsonSerializerOptions _options = new JsonSerializerOptions
        {
            WriteIndented = true,
            Encoder = JavaScriptEncoder.Create(UnicodeRanges.All)
        };

        /// <summary>Прочитать список заявок из файла JSON.</summary>
        public List<CreditApplication> Load(string path)
        {
            string json = File.ReadAllText(path, Encoding.UTF8);
            // Если файл пустой — возвращаем пустой список, а не null.
            return JsonSerializer.Deserialize<List<CreditApplication>>(json, _options)
                   ?? new List<CreditApplication>();
        }

        /// <summary>Записать список заявок в файл JSON (файл перезаписывается).</summary>
        public void Save(string path, List<CreditApplication> applications)
        {
            string json = JsonSerializer.Serialize(applications, _options);
            File.WriteAllText(path, json, Encoding.UTF8);
        }

        /// <summary>Удалить файл с диска.</summary>
        public void Delete(string path)
        {
            File.Delete(path);
        }

        /// <summary>Сохранить произвольный текст (отчёт) в файл TXT.</summary>
        public void SaveText(string path, string text)
        {
            File.WriteAllText(path, text, Encoding.UTF8);
        }
    }
}
